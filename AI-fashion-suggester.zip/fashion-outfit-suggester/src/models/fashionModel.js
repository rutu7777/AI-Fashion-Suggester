// src/models/fashionModel.js
// Fashion recommendation engine and data models

/**
 * Fashion Recommendation System
 * Provides outfit combinations, color matching, and style suggestions
 */

// Fashion color theory - complementary and matching colors
export const colorPalette = {
  red: {
    name: 'Red',
    hex: '#DC143C',
    complements: ['white', 'black', 'gold', 'cream', 'navy'],
    occasions: ['wedding', 'party', 'festival'],
    season: ['winter', 'autumn']
  },
  blue: {
    name: 'Blue',
    hex: '#0047AB',
    complements: ['white', 'silver', 'grey', 'beige', 'gold'],
    occasions: ['office', 'casual', 'formal'],
    season: ['summer', 'spring', 'all']
  },
  green: {
    name: 'Green',
    hex: '#228B22',
    complements: ['brown', 'beige', 'gold', 'white', 'cream'],
    occasions: ['casual', 'festive', 'traditional'],
    season: ['spring', 'summer']
  },
  yellow: {
    name: 'Yellow',
    hex: '#FFD700',
    complements: ['white', 'grey', 'blue', 'purple', 'brown'],
    occasions: ['casual', 'festive', 'traditional'],
    season: ['spring', 'summer']
  },
  pink: {
    name: 'Pink',
    hex: '#FF69B4',
    complements: ['white', 'gold', 'silver', 'grey', 'navy'],
    occasions: ['party', 'casual', 'festive'],
    season: ['spring', 'summer']
  },
  orange: {
    name: 'Orange',
    hex: '#FF8C00',
    complements: ['white', 'brown', 'blue', 'grey', 'gold'],
    occasions: ['festive', 'casual', 'traditional'],
    season: ['autumn', 'summer']
  },
  purple: {
    name: 'Purple',
    hex: '#800080',
    complements: ['gold', 'silver', 'white', 'grey', 'yellow'],
    occasions: ['wedding', 'festive', 'formal'],
    season: ['winter', 'autumn']
  },
  white: {
    name: 'White',
    hex: '#FFFFFF',
    complements: ['all colors'],
    occasions: ['all'],
    season: ['all']
  },
  black: {
    name: 'Black',
    hex: '#000000',
    complements: ['all colors'],
    occasions: ['all'],
    season: ['all']
  },
  gold: {
    name: 'Gold',
    hex: '#FFD700',
    complements: ['red', 'blue', 'green', 'purple', 'maroon'],
    occasions: ['wedding', 'festive', 'traditional'],
    season: ['all']
  }
};

// Outfit database by occasion
export const outfitDatabase = {
  wedding: {
    female: [
      {
        name: 'Designer Lehenga',
        description: 'Heavy embroidered lehenga with dupatta',
        colors: ['red', 'maroon', 'gold', 'pink', 'royal blue'],
        jewelry: ['heavy necklace set', 'maang tikka', 'jhumkas', 'bangles'],
        footwear: ['embellished heels', 'mojaris', 'kolhapuris'],
        accessories: ['potli bag', 'clutch'],
        styling: ['hair bun with flowers', 'bold makeup', 'alta on hands'],
        fabric: ['silk', 'velvet', 'brocade', 'georgette with heavy work']
      },
      {
        name: 'Traditional Saree',
        description: 'Rich silk saree with heavy border',
        colors: ['red', 'maroon', 'gold', 'emerald green', 'royal blue'],
        jewelry: ['statement necklace', 'chandelier earrings', 'bangles', 'rings'],
        footwear: ['heels', 'embellished sandals'],
        accessories: ['designer clutch', 'shawl'],
        styling: ['elegant bun', 'smokey eyes', 'bold lipstick'],
        fabric: ['banarasi silk', 'kanjeevaram', 'tissue', 'velvet']
      },
      {
        name: 'Anarkali Suit',
        description: 'Floor-length anarkali with heavy dupatta',
        colors: ['pink', 'peach', 'mint green', 'lavender', 'gold'],
        jewelry: ['choker necklace', 'jhumkas', 'maang tikka'],
        footwear: ['heels', 'mojaris'],
        accessories: ['potli', 'clutch'],
        styling: ['side braid', 'natural glam makeup'],
        fabric: ['georgette', 'net', 'silk']
      }
    ],
    male: [
      {
        name: 'Sherwani',
        description: 'Traditional sherwani with churidar',
        colors: ['cream', 'gold', 'maroon', 'navy', 'black'],
        jewelry: ['brooch', 'cufflinks', 'watch'],
        footwear: ['mojaris', 'juttis'],
        accessories: ['turban/safa', 'pocket square'],
        styling: ['well-groomed beard', 'cologne'],
        fabric: ['silk', 'brocade', 'velvet']
      },
      {
        name: 'Indo-Western Suit',
        description: 'Fusion of Indian and western wear',
        colors: ['navy', 'grey', 'black', 'wine'],
        jewelry: ['watch', 'cufflinks'],
        footwear: ['formal shoes', 'mojaris'],
        accessories: ['tie/bow tie', 'pocket square'],
        styling: ['styled hair', 'clean shave or beard'],
        fabric: ['cotton blend', 'linen', 'silk']
      }
    ]
  },
  
  party: {
    female: [
      {
        name: 'Cocktail Dress',
        description: 'Western cocktail dress',
        colors: ['black', 'red', 'navy', 'emerald', 'wine'],
        jewelry: ['statement earrings', 'bracelet', 'ring'],
        footwear: ['high heels', 'stilettos'],
        accessories: ['clutch', 'watch'],
        styling: ['loose curls', 'bold makeup', 'nail art'],
        fabric: ['satin', 'velvet', 'sequin']
      },
      {
        name: 'Indo-Western',
        description: 'Crop top with palazzo or dhoti pants',
        colors: ['pastels', 'metallics', 'jewel tones'],
        jewelry: ['contemporary jewelry', 'layered necklaces'],
        footwear: ['heels', 'wedges'],
        accessories: ['sling bag', 'sunglasses'],
        styling: ['high ponytail', 'dewy makeup'],
        fabric: ['georgette', 'crepe', 'silk']
      },
      {
        name: 'Saree - Modern Drape',
        description: 'Contemporary saree with modern blouse',
        colors: ['black', 'pastels', 'prints'],
        jewelry: ['minimal jewelry', 'statement piece'],
        footwear: ['heels', 'block heels'],
        accessories: ['clutch'],
        styling: ['sleek hair', 'modern makeup'],
        fabric: ['georgette', 'chiffon', 'satin']
      }
    ],
    male: [
      {
        name: 'Blazer with Chinos',
        description: 'Smart casual blazer combo',
        colors: ['navy', 'grey', 'black', 'burgundy'],
        jewelry: ['watch', 'bracelet'],
        footwear: ['loafers', 'formal shoes'],
        accessories: ['tie optional', 'pocket square'],
        styling: ['styled hair', 'cologne'],
        fabric: ['cotton', 'linen blend']
      }
    ]
  },
  
  office: {
    female: [
      {
        name: 'Formal Shirt with Trousers',
        description: 'Professional office wear',
        colors: ['white', 'blue', 'grey', 'black', 'pastels'],
        jewelry: ['small studs', 'watch', 'simple necklace'],
        footwear: ['formal shoes', 'low heels', 'flats'],
        accessories: ['laptop bag', 'belt'],
        styling: ['tied hair or neat style', 'minimal makeup'],
        fabric: ['cotton', 'polyester blend']
      },
      {
        name: 'Formal Kurti with Pants',
        description: 'Indian formal wear',
        colors: ['navy', 'grey', 'beige', 'white', 'black'],
        jewelry: ['small earrings', 'watch'],
        footwear: ['formal flats', 'low heels'],
        accessories: ['tote bag', 'scarf'],
        styling: ['neat hairstyle', 'natural makeup'],
        fabric: ['cotton', 'linen']
      }
    ],
    male: [
      {
        name: 'Formal Shirt with Trousers',
        description: 'Standard office attire',
        colors: ['white', 'blue', 'grey', 'black'],
        jewelry: ['watch', 'belt'],
        footwear: ['formal shoes'],
        accessories: ['tie', 'briefcase'],
        styling: ['neat hair', 'clean shave'],
        fabric: ['cotton', 'polyester blend']
      }
    ]
  },
  
  casual: {
    female: [
      {
        name: 'T-shirt with Jeans',
        description: 'Everyday casual wear',
        colors: ['any comfortable colors'],
        jewelry: ['minimal - watch, small earrings'],
        footwear: ['sneakers', 'flats', 'sandals'],
        accessories: ['backpack', 'crossbody bag', 'sunglasses'],
        styling: ['natural hair', 'light/no makeup'],
        fabric: ['cotton', 'denim']
      },
      {
        name: 'Kurti with Leggings',
        description: 'Indian casual wear',
        colors: ['bright colors', 'prints', 'pastels'],
        jewelry: ['simple earrings', 'bangles'],
        footwear: ['flats', 'sandals', 'juttis'],
        accessories: ['tote bag', 'dupatta'],
        styling: ['comfortable hairstyle'],
        fabric: ['cotton', 'rayon']
      }
    ],
    male: [
      {
        name: 'T-shirt with Jeans',
        description: 'Basic casual outfit',
        colors: ['any colors'],
        jewelry: ['watch'],
        footwear: ['sneakers', 'casual shoes'],
        accessories: ['backpack', 'cap'],
        styling: ['natural'],
        fabric: ['cotton']
      }
    ]
  },
  
  traditional: {
    female: [
      {
        name: 'Traditional Saree',
        description: 'Classic Indian saree',
        colors: ['traditional colors - red, green, yellow, orange'],
        jewelry: ['traditional gold jewelry', 'bangles', 'bindi'],
        footwear: ['traditional sandals', 'kolhapuris'],
        accessories: ['bindi', 'flowers in hair'],
        styling: ['traditional bun', 'bindi', 'mehendi'],
        fabric: ['cotton', 'silk', 'handloom']
      },
      {
        name: 'Salwar Kameez',
        description: 'Traditional punjabi suit',
        colors: ['bright traditional colors'],
        jewelry: ['traditional jewelry', 'bangles'],
        footwear: ['juttis', 'mojaris'],
        accessories: ['dupatta', 'potli'],
        styling: ['braid', 'bindi'],
        fabric: ['cotton', 'silk']
      }
    ]
  }
};

// Weather-based fabric recommendations
export const fabricByWeather = {
  hot: {
    temp: '>30°C',
    fabrics: ['cotton', 'linen', 'light georgette', 'chiffon', 'rayon'],
    avoid: ['velvet', 'heavy silk', 'wool', 'synthetic'],
    colors: ['light colors', 'pastels', 'white'],
    tips: ['Breathable fabrics', 'Loose fitting', 'Light layers']
  },
  warm: {
    temp: '25-30°C',
    fabrics: ['cotton', 'linen', 'georgette', 'silk blend'],
    avoid: ['heavy fabrics'],
    colors: ['any colors'],
    tips: ['Comfortable fabrics', 'Medium layers']
  },
  cool: {
    temp: '15-25°C',
    fabrics: ['cotton', 'silk', 'georgette', 'light wool'],
    avoid: ['very light fabrics'],
    colors: ['any colors', 'rich tones'],
    tips: ['Layering recommended', 'Light jackets']
  },
  cold: {
    temp: '<15°C',
    fabrics: ['wool', 'velvet', 'heavy silk', 'pashmina', 'thick cotton'],
    avoid: ['chiffon', 'georgette', 'thin fabrics'],
    colors: ['dark colors', 'rich tones'],
    tips: ['Heavy layers', 'Shawls and stoles', 'Jackets mandatory']
  }
};

// Jewelry recommendations by outfit
export const jewelryGuide = {
  heavy_outfit: {
    jewelry: 'minimal',
    description: 'Heavy outfits need lighter jewelry',
    examples: ['small earrings', 'thin bangles', 'delicate necklace']
  },
  simple_outfit: {
    jewelry: 'statement',
    description: 'Simple outfits can handle bold jewelry',
    examples: ['statement necklace', 'large earrings', 'chunky bangles']
  },
  traditional: {
    jewelry: 'traditional',
    description: 'Traditional outfits need traditional jewelry',
    examples: ['kundan', 'polki', 'temple jewelry', 'antique gold']
  },
  western: {
    jewelry: 'contemporary',
    description: 'Western wear needs modern jewelry',
    examples: ['minimal gold', 'silver', 'platinum', 'diamonds']
  }
};

// Style matching algorithm
export const matchOutfitToOccasion = (occasion, gender = 'female', weather = null) => {
  const occasionKey = occasion.toLowerCase();
  
  // Find matching occasion in database
  let matchedOccasion = null;
  for (const [key, value] of Object.entries(outfitDatabase)) {
    if (occasionKey.includes(key)) {
      matchedOccasion = key;
      break;
    }
  }
  
  // Default to casual if no match
  if (!matchedOccasion) {
    matchedOccasion = 'casual';
  }
  
  const outfits = outfitDatabase[matchedOccasion][gender] || outfitDatabase[matchedOccasion].female;
  
  // Apply weather filter if provided
  if (weather) {
    const temp = weather.temp;
    let weatherCategory = 'warm';
    
    if (temp > 30) weatherCategory = 'hot';
    else if (temp < 15) weatherCategory = 'cold';
    else if (temp < 25) weatherCategory = 'cool';
    
    const fabricRec = fabricByWeather[weatherCategory];
    
    return {
      outfits,
      weatherRecommendation: fabricRec,
      occasion: matchedOccasion
    };
  }
  
  return {
    outfits,
    occasion: matchedOccasion
  };
};

// Color coordination checker
export const checkColorCoordination = (colors) => {
  if (!Array.isArray(colors) || colors.length < 2) {
    return { compatible: true, message: 'Single color outfit' };
  }
  
  const colorNames = colors.map(c => c.toLowerCase());
  
  // Check if colors complement each other
  for (const color of colorNames) {
    const colorInfo = colorPalette[color];
    if (colorInfo) {
      const otherColors = colorNames.filter(c => c !== color);
      const allMatch = otherColors.every(c => 
        colorInfo.complements.includes(c) || colorInfo.complements.includes('all colors')
      );
      
      if (!allMatch) {
        return {
          compatible: false,
          message: `${color} doesn't pair well with some colors in the outfit`,
          suggestion: `Try pairing ${color} with: ${colorInfo.complements.slice(0, 3).join(', ')}`
        };
      }
    }
  }
  
  return {
    compatible: true,
    message: 'Great color coordination!'
  };
};

// Outfit scoring algorithm
export const scoreOutfit = (analysisData, occasion, weather) => {
  let score = 70; // Base score
  const feedback = [];
  
  // Check color coordination
  if (analysisData.dominantColors) {
    const colorCheck = checkColorCoordination(analysisData.dominantColors);
    if (colorCheck.compatible) {
      score += 10;
      feedback.push('✅ Excellent color coordination');
    } else {
      score -= 5;
      feedback.push(`⚠️ ${colorCheck.message}`);
    }
  }
  
  // Check weather appropriateness
  if (weather) {
    const temp = weather.temp;
    if (temp > 30) {
      feedback.push('🌞 Hot weather - ensure breathable fabrics');
    } else if (temp < 15) {
      feedback.push('🧥 Cold weather - layer up appropriately');
      score += 5;
    } else {
      score += 10;
      feedback.push('✅ Perfect weather for this outfit');
    }
  }
  
  // Check occasion match
  if (occasion) {
    score += 10;
    feedback.push(`✅ Appropriate for ${occasion}`);
  }
  
  // Ensure score is within bounds
  score = Math.min(Math.max(score, 0), 100);
  
  return {
    score,
    feedback,
    verdict: score >= 85 ? 'Excellent!' : score >= 70 ? 'Good!' : score >= 60 ? 'Decent' : 'Needs Work'
  };
};

// Export all functions
export default {
  colorPalette,
  outfitDatabase,
  fabricByWeather,
  jewelryGuide,
  matchOutfitToOccasion,
  checkColorCoordination,
  scoreOutfit
};