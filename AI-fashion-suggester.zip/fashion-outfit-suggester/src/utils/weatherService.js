import axios from 'axios';

const API_BASE_URL = 'http://localhost:3001/api';

export const fetchWeatherData = async (city) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/weather/${city}`);
    return response.data;
  } catch (error) {
    console.error('Weather fetch error:', error);
    throw new Error('Unable to fetch weather data. Please check city name.');
  }
};

export const getWeatherSuggestions = (temp, condition) => {
  const suggestions = [];
  
  if (temp < 15) {
    suggestions.push('🧥 Layer up! Wear warm jackets, shawls, or cardigans');
    suggestions.push('🧣 Add scarves and stoles for extra warmth');
    suggestions.push('👢 Closed shoes or boots recommended');
  } else if (temp < 25) {
    suggestions.push('👕 Perfect weather for light cotton or linen');
    suggestions.push('👗 Kurtis, casual dresses work great');
    suggestions.push('🩴 Both open and closed footwear suitable');
  } else {
    suggestions.push('🌞 Choose breathable fabrics - cotton, linen, or georgette');
    suggestions.push('👒 Carry sunglasses and a cap/dupatta');
    suggestions.push('💧 Stay hydrated! Light colors recommended');
  }

  if (condition.toLowerCase().includes('rain') || 
      condition.toLowerCase().includes('drizzle') || 
      condition.toLowerCase().includes('thunder')) {
    suggestions.push('☔ Don\'t forget umbrella! Avoid silk/heavy fabrics');
    suggestions.push('👟 Waterproof footwear recommended');
  }

  return suggestions;
};