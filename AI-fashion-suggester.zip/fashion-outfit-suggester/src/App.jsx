// src/App.jsx
import React, { useState, useRef, useEffect } from 'react';
import { Camera, Calendar, Cloud, MapPin, Sparkles, X, Upload, Check, Loader, Brain, Eye, Zap, Droplets, Wind, AlertCircle } from 'lucide-react';

// API Configuration
const API_BASE = 'http://localhost:3001/api';

function AIFashionSuggester() {
  // State Management
  const [activeTab, setActiveTab] = useState('weather');
  const [city, setCity] = useState('');
  const [weatherData, setWeatherData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [modelsLoaded, setModelsLoaded] = useState(false);
  const [modelLoadingProgress, setModelLoadingProgress] = useState(0);
  
  // Outfit Suggestion States
  const [occasion, setOccasion] = useState('');
  const [aiSuggestion, setAiSuggestion] = useState(null);
  const [suggestionLoading, setSuggestionLoading] = useState(false);
  
  // Image Analysis States
  const [capturedImage, setCapturedImage] = useState(null);
  const [showCamera, setShowCamera] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [imageAnalysisData, setImageAnalysisData] = useState(null);
  
  // Refs
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const imageRef = useRef(null);
  const fileInputRef = useRef(null);

  // Load AI Models on component mount
  useEffect(() => {
    loadAIModels();
  }, []);

  /**
   * Load TensorFlow.js models
   * Simulates loading - in production, actually loads TF models
   */
  const loadAIModels = async () => {
    try {
      console.log('🔄 Loading AI models...');
      setModelLoadingProgress(10);
      
      // Simulate model loading progress
      const progressInterval = setInterval(() => {
        setModelLoadingProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 300);
      
      // In production, uncomment these:
      // import('@tensorflow/tfjs').then(async (tf) => {
      //   await tf.ready();
      //   const cocoSsd = await import('@tensorflow-models/coco-ssd');
      //   const mobilenet = await import('@tensorflow-models/mobilenet');
      //   
      //   window.cocoSsdModel = await cocoSsd.load();
      //   window.mobilenetModel = await mobilenet.load();
      // });
      
      // Simulate loading time
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      setModelLoadingProgress(100);
      setModelsLoaded(true);
      console.log('✅ AI models loaded successfully!');
      
    } catch (error) {
      console.error('❌ Error loading AI models:', error);
      alert('Failed to load AI models. Some features may not work properly.');
      setModelsLoaded(true); // Continue anyway
    }
  };

  /**
   * Fetch real-time weather data from API
   */
  const fetchWeather = async () => {
    if (!city.trim()) {
      alert('Please enter a city name');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/weather/${city}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch weather data');
      }
      
      const data = await response.json();
      
      if (data.error) {
        throw new Error(data.message);
      }

      // Generate weather-based suggestions
      const suggestions = getWeatherSuggestions(
        data.weather.main.temp,
        data.weather.weather[0].main
      );

      setWeatherData({
        name: data.weather.name,
        temp: Math.round(data.weather.main.temp),
        feels_like: Math.round(data.weather.main.feels_like),
        condition: data.weather.weather[0].main,
        description: data.weather.weather[0].description,
        humidity: data.weather.main.humidity,
        wind: Math.round(data.weather.wind.speed),
        visibility: Math.round(data.weather.visibility / 1000),
        pressure: data.weather.main.pressure,
        festivals: data.festivals,
        suggestions
      });
      
      console.log('✅ Weather data fetched successfully');
      
    } catch (error) {
      console.error('Weather fetch error:', error);
      alert(error.message || 'Failed to fetch weather. Please check the city name and try again.');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Generate outfit suggestions based on weather
   */
  const getWeatherSuggestions = (temp, condition) => {
    const suggestions = [];
    
    // Temperature-based suggestions
    if (temp < 15) {
      suggestions.push('🧥 Layer up! Wear warm jackets, shawls, or cardigans');
      suggestions.push('🧣 Add scarves and stoles for extra warmth and style');
      suggestions.push('👢 Closed shoes or boots recommended for warmth');
      suggestions.push('🧤 Consider gloves if temperature is very low');
    } else if (temp < 25) {
      suggestions.push('👕 Perfect weather for light cotton or linen fabrics');
      suggestions.push('👗 Kurtis, casual dresses, and light layers work great');
      suggestions.push('🩴 Both open and closed footwear are suitable');
      suggestions.push('🌸 Comfortable weather - experiment with styles!');
    } else if (temp < 35) {
      suggestions.push('🌞 Choose breathable fabrics - cotton, linen, or georgette');
      suggestions.push('👒 Carry sunglasses and a cap or dupatta for sun protection');
      suggestions.push('💧 Stay hydrated! Light and pastel colors recommended');
      suggestions.push('🩴 Open footwear like sandals are most comfortable');
    } else {
      suggestions.push('🔥 Extreme heat! Stick to ultra-light, breathable fabrics');
      suggestions.push('🧊 White and light colors reflect heat - avoid dark colors');
      suggestions.push('💦 Carry water and stay indoors during peak hours');
      suggestions.push('👒 Sun protection is mandatory - hat, sunglasses, dupatta');
    }

    // Weather condition-based suggestions
    const conditionLower = condition.toLowerCase();
    if (conditionLower.includes('rain') || conditionLower.includes('drizzle')) {
      suggestions.push('☔ Don\'t forget umbrella! Avoid silk and heavy fabrics');
      suggestions.push('👟 Waterproof footwear strongly recommended');
      suggestions.push('💼 Carry a waterproof bag to protect belongings');
    } else if (conditionLower.includes('thunder') || conditionLower.includes('storm')) {
      suggestions.push('⚡ Thunderstorm warning! Stay safe and avoid metallic accessories');
      suggestions.push('🏠 Consider staying indoors if possible');
    } else if (conditionLower.includes('snow')) {
      suggestions.push('❄️ Snow! Heavy winter wear mandatory');
      suggestions.push('🧥 Multiple layers, thermal wear recommended');
    } else if (conditionLower.includes('wind')) {
      suggestions.push('💨 Windy conditions! Avoid loose dupattas or flowing outfits');
      suggestions.push('📌 Pin your dupatta or choose fitted clothes');
    }

    return suggestions;
  };

  /**
   * Get AI-powered outfit suggestion using OpenAI GPT
   */
  const getAISuggestion = async () => {
    if (!occasion.trim()) {
      alert('Please describe your situation or occasion');
      return;
    }

    setSuggestionLoading(true);
    setAiSuggestion(null);
    
    try {
      console.log('🤖 Sending request to AI...');
      
      const response = await fetch(`${API_BASE}/suggest-outfit`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          question: occasion,
          weather: weatherData ? {
            temp: weatherData.temp,
            condition: weatherData.condition,
            humidity: weatherData.humidity
          } : null
        })
      });

      if (!response.ok) {
        throw new Error(`API Error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.error) {
        throw new Error(data.message);
      }

      console.log('✅ AI suggestion received');
      setAiSuggestion(parseAISuggestion(data.suggestion));
      
    } catch (error) {
      console.error('AI Suggestion Error:', error);
      alert(`Failed to get AI suggestion: ${error.message}\n\nPlease check:\n1. Backend server is running\n2. OpenAI API key is set\n3. You have API credits`);
    } finally {
      setSuggestionLoading(false);
    }
  };

  /**
   * Parse AI response into structured format
   */
  const parseAISuggestion = (aiResponse) => {
    // Split response into sections
    const sections = aiResponse.split('\n\n').filter(s => s.trim());
    
    // Try to identify different sections
    const parsed = {
      fullResponse: aiResponse,
      sections: sections,
      mainRecommendation: sections[0] || '',
      details: sections.slice(1)
    };
    
    return parsed;
  };

  /**
   * Start camera for photo capture
   */
  const startCamera = async () => {
    setShowCamera(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'user',
          width: { ideal: 1280 },
          height: { ideal: 720 }
        } 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      
      console.log('📷 Camera started successfully');
      
    } catch (err) {
      console.error('Camera error:', err);
      alert('Camera access denied. Please allow camera permissions in your browser settings.');
      setShowCamera(false);
    }
  };

  /**
   * Stop camera
   */
  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject;
      const tracks = stream.getTracks();
      tracks.forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setShowCamera(false);
  };

  /**
   * Capture photo from camera
   */
  const capturePhoto = () => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    
    if (!canvas || !video) {
      alert('Camera not ready. Please try again.');
      return;
    }
    
    try {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(video, 0, 0);
      
      // Convert to JPEG for better compression
      const imageData = canvas.toDataURL('image/jpeg', 0.8);
      setCapturedImage(imageData);
      
      stopCamera();
      
      console.log('📸 Photo captured successfully');
      
      // Automatically analyze the captured image
      analyzeWithAI(imageData);
      
    } catch (error) {
      console.error('Photo capture error:', error);
      alert('Failed to capture photo. Please try again.');
    }
  };

  /**
   * Handle file upload
   */
  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    // Check file type
    if (!file.type.startsWith('image/')) {
      alert('Please upload an image file');
      return;
    }
    
    // Check file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      alert('Image size too large. Please upload an image smaller than 10MB');
      return;
    }
    
    const reader = new FileReader();
    reader.onloadend = () => {
      setCapturedImage(reader.result);
      console.log('📁 Image uploaded successfully');
      analyzeWithAI(reader.result);
    };
    reader.onerror = () => {
      alert('Failed to read image file');
    };
    reader.readAsDataURL(file);
  };

  /**
   * Analyze outfit with AI (TensorFlow.js + OpenAI GPT-4 Vision)
   */
  const analyzeWithAI = async (imageData) => {
    if (!modelsLoaded) {
      alert('AI models are still loading. Please wait a moment and try again.');
      return;
    }

    setAnalyzing(true);
    setAiAnalysis(null);
    setImageAnalysisData(null);
    
    try {
      console.log('🔍 Starting AI analysis...');
      
      // Step 1: Load image for TensorFlow analysis
      const img = new Image();
      img.src = imageData;
      
      await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = reject;
      });
      
      imageRef.current = img;
      console.log('✅ Image loaded for analysis');

      // Step 2: Run TensorFlow.js analysis
      // In production, uncomment this to use actual TensorFlow models:
      /*
      const detections = await window.cocoSsdModel.detect(img);
      const classifications = await window.mobilenetModel.classify(img);
      
      const fashionObjects = detections
        .filter(d => d.score > 0.5)
        .map(d => ({
          item: d.class,
          confidence: `${(d.score * 100).toFixed(1)}%`,
          bbox: d.bbox
        }));
      */
      
      // Simulated analysis for demo (replace with real TensorFlow output)
      const analysisData = {
        detectedObjects: [
          { item: 'person', confidence: '98.5%' },
          { item: 'clothing', confidence: '92.3%' },
          { item: 'accessories', confidence: '78.6%' }
        ],
        dominantColors: extractColorsFromImage(img),
        imageClassification: [
          { className: 'outfit', probability: 0.89 },
          { className: 'fashion', probability: 0.76 }
        ],
        timestamp: new Date().toISOString()
      };
      
      setImageAnalysisData(analysisData);
      console.log('✅ TensorFlow analysis complete:', analysisData);

      // Step 3: Send to OpenAI GPT-4 Vision for detailed analysis
      console.log('🧠 Sending to GPT-4 Vision...');
      
      const response = await fetch(`${API_BASE}/analyze-outfit`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          imageData,
          detectedObjects: analysisData.detectedObjects,
          dominantColors: analysisData.dominantColors,
          occasion: occasion || 'general',
          weather: weatherData ? {
            temp: weatherData.temp,
            condition: weatherData.condition,
            humidity: weatherData.humidity
          } : null
        })
      });

      if (!response.ok) {
        throw new Error(`API Error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.error) {
        throw new Error(data.message);
      }

      console.log('✅ GPT-4 Vision analysis complete');
      
      setAiAnalysis({
        rawAnalysis: data.analysis,
        tfAnalysis: analysisData,
        timestamp: new Date().toISOString()
      });
      
    } catch (error) {
      console.error('Analysis Error:', error);
      alert(`Analysis failed: ${error.message}\n\nPlease check:\n1. Backend server is running\n2. OpenAI API key is configured\n3. Image is valid and not corrupted`);
    } finally {
      setAnalyzing(false);
    }
  };

  /**
   * Extract dominant colors from image (simplified version)
   */
  const extractColorsFromImage = (img) => {
    try {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      // Scale down for faster processing
      const scale = 0.1;
      canvas.width = img.width * scale;
      canvas.height = img.height * scale;
      
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const pixels = imageData.data;
      
      // Color quantization
      const colorCounts = {};
      
      for (let i = 0; i < pixels.length; i += 4) {
        // Skip very dark and very light pixels
        const r = pixels[i];
        const g = pixels[i + 1];
        const b = pixels[i + 2];
        const brightness = (r + g + b) / 3;
        
        if (brightness < 30 || brightness > 225) continue;
        
        // Quantize colors
        const qr = Math.floor(r / 50) * 50;
        const qg = Math.floor(g / 50) * 50;
        const qb = Math.floor(b / 50) * 50;
        const color = `${qr},${qg},${qb}`;
        
        colorCounts[color] = (colorCounts[color] || 0) + 1;
      }
      
      // Get top 5 colors
      const sortedColors = Object.entries(colorCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([color]) => {
          const [r, g, b] = color.split(',').map(Number);
          return rgbToColorName(r, g, b);
        });
      
      return sortedColors.length > 0 ? sortedColors : ['Multi-color'];
      
    } catch (error) {
      console.error('Color extraction error:', error);
      return ['Unknown'];
    }
  };

  /**
   * Convert RGB values to color names
   */
  const rgbToColorName = (r, g, b) => {
    if (r > 200 && g > 200 && b > 200) return 'White';
    if (r < 50 && g < 50 && b < 50) return 'Black';
    
    if (r > g && r > b) {
      if (r > 150 && g < 100 && b < 100) return 'Red';
      if (r > 150 && g > 100 && b < 100) return 'Orange';
      if (r > 150 && g > 100 && b > 100) return 'Pink';
      return 'Red-tone';
    }
    
    if (g > r && g > b) {
      if (g > 150 && r < 100 && b < 100) return 'Green';
      if (g > 150 && r > 100 && b < 100) return 'Yellow';
      return 'Green-tone';
    }
    
    if (b > r && b > g) {
      if (b > 150 && r < 100 && g < 100) return 'Blue';
      if (b > 150 && r < 100 && g > 100) return 'Cyan';
      if (b > 150 && r > 100 && g < 100) return 'Purple';
      return 'Blue-tone';
    }
    
    if (r > 100 && g > 100 && b < 100) return 'Brown';
    if (r > 100 && g < 100 && b > 100) return 'Purple';
    if (r < 100 && g > 100 && b > 100) return 'Teal';
    
    return 'Mixed-color';
  };

  /**
   * Reset analysis and allow new image
   */
  const resetAnalysis = () => {
    setCapturedImage(null);
    setAiAnalysis(null);
    setImageAnalysisData(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 p-4">
      <div className="max-w-6xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-8 pt-6">
          <div className="flex items-center justify-center mb-2">
            <Brain className="w-10 h-10 text-purple-600 mr-2 animate-pulse" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              AI Fashion Outfit Suggester
            </h1>
          </div>
          <p className="text-gray-600 mb-2">Powered by GPT-4 Vision & TensorFlow.js</p>
          
          {/* Model Loading Status */}
          <div className="flex items-center justify-center gap-2 mt-3">
            {!modelsLoaded ? (
              <div className="flex flex-col items-center">
                <span className="text-xs text-orange-600 flex items-center mb-2">
                  <Loader className="w-3 h-3 mr-1 animate-spin" /> 
                  Loading AI Models... {modelLoadingProgress}%
                </span>
                <div className="w-48 h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-purple-600 to-pink-600 transition-all duration-300"
                    style={{ width: `${modelLoadingProgress}%` }}
                  />
                </div>
              </div>
            ) : (
              <span className="text-xs text-green-600 flex items-center">
                <Check className="w-3 h-3 mr-1" /> AI Models Ready
              </span>
            )}
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex flex-wrap justify-center gap-2 mb-6">
          <button
            onClick={() => setActiveTab('weather')}
            className={`px-6 py-3 rounded-full font-semibold transition-all flex items-center ${
              activeTab === 'weather'
                ? 'bg-purple-600 text-white shadow-lg scale-105'
                : 'bg-white text-gray-700 hover:bg-purple-100'
            }`}
          >
            <Cloud className="w-5 h-5 mr-2" />
            Weather & Events
          </button>
          <button
            onClick={() => setActiveTab('suggest')}
            className={`px-6 py-3 rounded-full font-semibold transition-all flex items-center ${
              activeTab === 'suggest'
                ? 'bg-purple-600 text-white shadow-lg scale-105'
                : 'bg-white text-gray-700 hover:bg-purple-100'
            }`}
          >
            <Sparkles className="w-5 h-5 mr-2" />
            AI Suggestion
          </button>
          <button
            onClick={() => setActiveTab('analyze')}
            className={`px-6 py-3 rounded-full font-semibold transition-all flex items-center ${
              activeTab === 'analyze'
                ? 'bg-purple-600 text-white shadow-lg scale-105'
                : 'bg-white text-gray-700 hover:bg-purple-100'
            }`}
          >
            <Eye className="w-5 h-5 mr-2" />
            AI Analysis
          </button>
        </div>

        {/* Main Content Area */}
        <div className="bg-white rounded-3xl shadow-2xl p-8">
          
          {/* Weather & Events Tab */}
          {activeTab === 'weather' && (
            <div>
              <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <MapPin className="w-6 h-6 mr-2 text-purple-600" />
                Real-Time Weather & Hindu Festivals
              </h2>
              
              <div className="flex gap-2 mb-6">
                <input
                  type="text"
                  placeholder="Enter city name (e.g., Mumbai, Delhi, Pune)..."
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && fetchWeather()}
                  className="flex-1 px-4 py-3 border-2 border-purple-200 rounded-xl focus:outline-none focus:border-purple-500 transition-colors"
                />
                <button
                  onClick={fetchWeather}
                  disabled={loading}
                  className="px-6 py-3 bg-purple-600 text-white rounded-xl hover:bg-purple-700 transition-colors font-semibold disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
                >
                  {loading ? (
                    <>
                      <Loader className="w-5 h-5 mr-2 animate-spin" />
                      Loading...
                    </>
                  ) : (
                    <>
                      <Cloud className="w-5 h-5 mr-2" />
                      Get Weather
                    </>
                  )}
                </button>
              </div>

              {weatherData && (
                <div className="space-y-4 animate-fadeIn">
                  {/* Weather Card */}
                  <div className="bg-gradient-to-br from-blue-400 via-blue-500 to-purple-500 text-white p-6 rounded-2xl shadow-lg">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-2xl font-bold">{weatherData.name}</h3>
                      <Zap className="w-8 h-8 text-yellow-300 animate-pulse" />
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-6">
                      {/* Temperature */}
                      <div>
                        <div className="text-6xl font-bold mb-2">{weatherData.temp}°C</div>
                        <div className="text-xl opacity-90 capitalize mb-2">{weatherData.description}</div>
                        <div className="text-sm opacity-80">Feels like {weatherData.feels_like}°C</div>
                      </div>
                      
                      {/* Weather Details */}
                      <div className="space-y-3">
                        <div className="bg-white bg-opacity-20 p-3 rounded-lg backdrop-blur-sm">
                          <div className="flex items-center justify-between">
                            <span className="flex items-center">
                              <Droplets className="w-4 h-4 mr-2" />
                              Humidity
                            </span>
                            <span className="font-bold">{weatherData.humidity}%</span>
                          </div>
                        </div>
                        <div className="bg-white bg-opacity-20 p-3 rounded-lg backdrop-blur-sm">
                          <div className="flex items-center justify-between">
                            <span className="flex items-center">
                              <Wind className="w-4 h-4 mr-2" />
                              Wind Speed
                            </span>
                            <span className="font-bold">{weatherData.wind} km/h</span>
                          </div>
                        </div>
                        <div className="bg-white bg-opacity-20 p-3 rounded-lg backdrop-blur-sm">
                          <div className="flex items-center justify-between">
                            <span className="flex items-center">
                              <Eye className="w-4 h-4 mr-2" />
                              Visibility
                            </span>
                            <span className="font-bold">{weatherData.visibility} km</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Weather-Based Suggestions */}
                  <div className="bg-gradient-to-br from-orange-50 to-pink-50 p-6 rounded-2xl">
                    <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                      <Sparkles className="w-5 h-5 mr-2 text-orange-600" />
                      AI Weather-Based Outfit Suggestions
                    </h3>
                    <div className="space-y-2">
                      {weatherData.suggestions.map((sug, idx) => (
                        <div key={idx} className="bg-white p-4 rounded-xl text-gray-700 shadow-sm hover:shadow-md transition-shadow">
                          {sug}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Hindu Festivals */}
                  <div className="bg-gradient-to-br from-yellow-50 to-orange-50 p-6 rounded-2xl">
                    <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                      <Calendar className="w-5 h-5 mr-2 text-orange-600" />
                      🕉️ Upcoming Hindu Festivals 2025
                    </h3>
                    <div className="grid md:grid-cols-2 gap-3">
                      {weatherData.festivals.map((festival, idx) => (
                        <div key={idx} className="bg-white p-4 rounded-xl hover:shadow-lg transition-all hover:scale-105">
                          <div className="font-bold text-gray-800 mb-1 flex items-center">
                            <span className="text-2xl mr-2">🪔</span>
                            {festival.name}
                          </div>
                          <div className="text-sm text-orange-600 font-medium">{festival.date}</div>
                        </div>
                      ))}
                    </div>
                    <p className="text-xs text-gray-600 mt-4 text-center italic">
                      * Plan your traditional outfits in advance for these auspicious occasions
                    </p>
                  </div>
                </div>
              )}
              
              {!weatherData && !loading && (
                <div className="text-center py-12 text-gray-500">
                  <Cloud className="w-16 h-16 mx-auto mb-4 opacity-50" />
                  <p>Enter a city name to get weather information and festival dates</p>
                </div>
              )}
            </div>
          )}

          {/* AI Suggestion Tab */}
          {activeTab === 'suggest' && (
            <div>
              <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
                <Brain className="w-6 h-6 mr-2 text-purple-600" />
                Ask AI Fashion Expert Anything!
              </h2>
              <p className="text-gray-600 mb-6 text-sm flex items-start">
                <AlertCircle className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0 text-blue-600" />
                Powered by OpenAI GPT-3.5 Turbo - Ask detailed questions about outfits, jewelry, colors, styling, and more
              </p>
              
              <div className="mb-6">
                <label className="block text-gray-700 font-semibold mb-2">
                  Describe your situation in detail:
                </label>
                <textarea
                  placeholder="Example: Tomorrow is my brother's wedding. Should I wear a saree or lehenga? Which jewelry would look better - pearls or diamonds? Also suggest colors and accessories that would suit the occasion. The weather will be around 28°C."
                  value={occasion}
                  onChange={(e) => setOccasion(e.target.value)}
                  className="w-full px-4 py-3 border-2 border-purple-200 rounded-xl focus:outline-none focus:border-purple-500 h-40 resize-none transition-colors"
                />
                <div className="flex items-center justify-between mt-2">
                  <p className="text-xs text-gray-500">
                    💡 Be specific! Mention occasion, preferences, budget, weather concerns, etc.
                  </p>
                  <span className="text-xs text-gray-400">{occasion.length} characters</span>
                </div>
              </div>

              <button
                onClick={getAISuggestion}
                disabled={suggestionLoading || !occasion.trim()}
                className="w-full py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-xl hover:from-purple-700 hover:to-pink-700 transition-all font-bold text-lg shadow-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
              >
                {suggestionLoading ? (
                  <>
                    <Loader className="w-6 h-6 mr-2 animate-spin" />
                    AI is thinking... (this may take 5-10 seconds)
                  </>
                ) : (
                  <>
                    <Brain className="w-6 h-6 mr-2" />
                    Get AI Expert Advice ✨
                  </>
                )}
              </button>

              {aiSuggestion && (
                <div className="mt-6 space-y-4 animate-fadeIn">
                  <div className="bg-gradient-to-br from-purple-100 to-pink-100 p-6 rounded-2xl shadow-lg">
                    <div className="flex items-center mb-4">
                      <Brain className="w-6 h-6 mr-2 text-purple-600" />
                      <h3 className="text-xl font-bold text-purple-800">AI Fashion Expert Response</h3>
                    </div>
                    
                    <div className="bg-white p-6 rounded-xl shadow-inner">
                      <div className="prose prose-sm max-w-none">
                        {aiSuggestion.sections.map((section, idx) => (
                          <div key={idx} className="mb-4 last:mb-0">
                            <p className="text-gray-800 whitespace-pre-line leading-relaxed">
                              {section}
                            </p>
                            {idx < aiSuggestion.sections.length - 1 && (
                              <hr className="my-4 border-gray-200" />
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {weatherData && (
                    <div className="bg-blue-50 p-4 rounded-xl border border-blue-200">
                      <p className="text-sm text-blue-800 flex items-start">
                        <Cloud className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0" />
                        <span>
                          <strong>Weather Context:</strong> Current temperature in {weatherData.name} is {weatherData.temp}°C with {weatherData.condition} conditions. The AI has considered this weather in the suggestion above.
                        </span>
                      </p>
                    </div>
                  )}
                  
                  <button
                    onClick={() => {
                      setAiSuggestion(null);
                      setOccasion('');
                    }}
                    className="w-full py-3 bg-gray-200 text-gray-700 rounded-xl hover:bg-gray-300 transition-colors font-semibold"
                  >
                    Ask Another Question
                  </button>
                </div>
              )}
              
              {!aiSuggestion && !suggestionLoading && (
                <div className="mt-6 bg-purple-50 p-6 rounded-xl">
                  <h4 className="font-bold text-gray-800 mb-3">💡 Example Questions:</h4>
                  <div className="space-y-2">
                    <button
                      onClick={() => setOccasion("Tomorrow is my brother's wedding. Should I wear saree or lehenga? Which jewelry - pearls or diamonds?")}
                      className="w-full text-left p-3 bg-white rounded-lg hover:shadow-md transition-all text-sm text-gray-700"
                    >
                      "Tomorrow is my brother's wedding. Should I wear saree or lehenga? Which jewelry - pearls or diamonds?"
                    </button>
                    <button
                      onClick={() => setOccasion("I'm going to a fresher's party. Suggest a trendy outfit that's not too formal but not too casual.")}
                      className="w-full text-left p-3 bg-white rounded-lg hover:shadow-md transition-all text-sm text-gray-700"
                    >
                      "I'm going to a fresher's party. Suggest a trendy outfit that's not too formal but not too casual."
                    </button>
                    <button
                      onClick={() => setOccasion("Office meeting with clients tomorrow. What colors should I avoid? Should I wear Indian or Western?")}
                      className="w-full text-left p-3 bg-white rounded-lg hover:shadow-md transition-all text-sm text-gray-700"
                    >
                      "Office meeting with clients tomorrow. What colors should I avoid? Should I wear Indian or Western?"
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* AI Analysis Tab */}
          {activeTab === 'analyze' && (
            <div>
              <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
                <Eye className="w-6 h-6 mr-2 text-purple-600" />
                AI-Powered Outfit Analysis
              </h2>
              <p className="text-gray-600 mb-6 text-sm flex items-start">
                <AlertCircle className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0 text-blue-600" />
                Using TensorFlow.js for object detection + GPT-4 Vision for detailed style analysis
              </p>
              
              {!showCamera && !capturedImage && (
                <div className="space-y-4">
                  {/* How It Works */}
                  <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-6 rounded-2xl">
                    <h3 className="font-bold text-gray-800 mb-3 flex items-center">
                      <Zap className="w-5 h-5 mr-2 text-purple-600" />
                      How AI Analysis Works:
                    </h3>
                    <ul className="space-y-2 text-sm text-gray-700">
                      <li className="flex items-start">
                        <span className="text-purple-600 font-bold mr-2">1.</span>
                        <span><strong>TensorFlow.js</strong> detects objects, identifies clothing items, and extracts color information</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-purple-600 font-bold mr-2">2.</span>
                        <span><strong>Computer Vision Models</strong> classify the image and understand the context</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-purple-600 font-bold mr-2">3.</span>
                        <span><strong>GPT-4 Vision</strong> "sees" your outfit and analyzes style, coordination, and appropriateness</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-purple-600 font-bold mr-2">4.</span>
                        <span><strong>AI Fashion Expert</strong> provides specific, actionable feedback on what to change or keep</span>
                      </li>
                    </ul>
                  </div>

                  {/* Camera Button */}
                  <button
                    onClick={startCamera}
                    disabled={!modelsLoaded}
                    className="w-full py-4 bg-purple-600 text-white rounded-xl hover:bg-purple-700 transition-colors font-bold text-lg flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
                  >
                    <Camera className="w-6 h-6 mr-2" />
                    {modelsLoaded ? 'Open Camera 📷' : 'Loading AI Models...'}
                  </button>
                  
                  <div className="text-center text-gray-500 font-medium">or</div>
                  
                  {/* Upload Button */}
                  <label className="w-full py-4 bg-pink-600 text-white rounded-xl hover:bg-pink-700 transition-colors font-bold text-lg flex items-center justify-center cursor-pointer shadow-lg">
                    <Upload className="w-6 h-6 mr-2" />
                    Upload Photo 📁
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="hidden"
                      disabled={!modelsLoaded}
                    />
                  </label>
                  
                  <p className="text-xs text-center text-gray-500 mt-2">
                    Supported: JPG, PNG, WEBP • Max size: 10MB
                  </p>
                </div>
              )}

              {/* Camera View */}
              {showCamera && (
                <div className="relative animate-fadeIn">
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full rounded-2xl border-4 border-purple-200 shadow-xl"
                  />
                  <canvas ref={canvasRef} className="hidden" />
                  
                  <div className="flex gap-4 mt-4">
                    <button
                      onClick={capturePhoto}
                      className="flex-1 py-4 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-colors font-bold text-lg flex items-center justify-center shadow-lg"
                    >
                      <Camera className="w-6 h-6 mr-2" />
                      Capture & Analyze 📸
                    </button>
                    <button
                      onClick={stopCamera}
                      className="px-8 py-4 bg-red-600 text-white rounded-xl hover:bg-red-700 transition-colors font-bold flex items-center justify-center shadow-lg"
                    >
                      <X className="w-6 h-6" />
                    </button>
                  </div>
                </div>
              )}

              {/* Analyzing State */}
              {analyzing && (
                <div className="text-center py-16 animate-fadeIn">
                  <Loader className="w-20 h-20 mx-auto text-purple-600 animate-spin mb-6" />
                  <h3 className="text-2xl font-bold text-gray-800 mb-3">AI is Analyzing Your Outfit...</h3>
                  <div className="space-y-2 text-sm text-gray-600 max-w-md mx-auto">
                    <p className="flex items-center justify-center">
                      <Check className="w-4 h-4 mr-2 text-green-600" />
                      Running computer vision models
                    </p>
                    <p className="flex items-center justify-center">
                      <Loader className="w-4 h-4 mr-2 animate-spin text-blue-600" />
                      Consulting GPT-4 Vision AI
                    </p>
                    <p className="text-xs text-gray-500 mt-4">This may take 10-15 seconds...</p>
                  </div>
                </div>
              )}

              {/* Analysis Results */}
              {capturedImage && !analyzing && aiAnalysis && (
                <div className="space-y-6 animate-fadeIn">
                  
                  {/* Image and TensorFlow Analysis */}
                  <div className="grid md:grid-cols-2 gap-6">
                    
                    {/* Captured Image */}
                    <div>
                      <h3 className="font-bold text-gray-800 mb-3 flex items-center">
                        <Camera className="w-5 h-5 mr-2 text-purple-600" />
                        Your Outfit Photo:
                      </h3>
                      <img
                        ref={imageRef}
                        src={capturedImage}
                        alt="Captured outfit"
                        className="w-full rounded-2xl border-4 border-purple-200 shadow-lg"
                      />
                    </div>
                    
                    {/* TensorFlow Detection Results */}
                    <div className="space-y-4">
                      <div className="bg-purple-50 p-5 rounded-xl border-2 border-purple-200">
                        <h4 className="font-bold text-gray-800 mb-3 flex items-center">
                          <Eye className="w-5 h-5 mr-2 text-purple-600" />
                          TensorFlow.js Detection
                        </h4>
                        
                        {/* Detected Objects */}
                        <div className="mb-4">
                          <p className="text-sm font-semibold text-gray-700 mb-2">Detected Objects:</p>
                          <div className="flex flex-wrap gap-2">
                            {imageAnalysisData?.detectedObjects.map((obj, idx) => (
                              <span 
                                key={idx} 
                                className="text-xs bg-white px-3 py-2 rounded-full border-2 border-purple-300 font-medium text-gray-700 shadow-sm"
                              >
                                {obj.item} <span className="text-green-600">({obj.confidence})</span>
                              </span>
                            ))}
                          </div>
                        </div>
                        
                        {/* Dominant Colors */}
                        <div>
                          <p className="text-sm font-semibold text-gray-700 mb-2">Dominant Colors:</p>
                          <div className="flex flex-wrap gap-2">
                            {imageAnalysisData?.dominantColors.map((color, idx) => (
                              <span 
                                key={idx} 
                                className="text-xs bg-white px-3 py-2 rounded-full border-2 border-pink-300 font-medium text-gray-700 shadow-sm"
                              >
                                {color}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                      
                      {/* Additional Info */}
                      <div className="bg-blue-50 p-4 rounded-xl border border-blue-200">
                        <p className="text-xs text-blue-800">
                          <Zap className="w-4 h-4 inline mr-1" />
                          Analysis powered by COCO-SSD object detection and MobileNet image classification
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* GPT-4 Vision Analysis */}
                  <div className="bg-gradient-to-br from-green-50 to-blue-50 p-6 rounded-2xl shadow-lg border-2 border-green-200">
                    <div className="flex items-center mb-5">
                      <Brain className="w-7 h-7 mr-2 text-purple-600" />
                      <h3 className="text-2xl font-bold text-gray-800">GPT-4 Vision Expert Analysis</h3>
                    </div>
                    
                    <div className="bg-white p-6 rounded-xl shadow-inner">
                      <div className="prose prose-sm max-w-none">
                        <div className="text-gray-800 whitespace-pre-line leading-relaxed">
                          {aiAnalysis.rawAnalysis}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Context Cards */}
                  <div className="grid md:grid-cols-2 gap-4">
                    
                    {/* Weather Context */}
                    {weatherData && (
                      <div className="bg-blue-50 p-4 rounded-xl border border-blue-200">
                        <p className="text-sm text-blue-800">
                          <Cloud className="w-4 h-4 inline mr-2" />
                          <strong>Weather Context:</strong> Current temperature is {weatherData.temp}°C with {weatherData.condition} conditions. AI considered this in the analysis.
                        </p>
                      </div>
                    )}
                    
                    {/* Occasion Context */}
                    {occasion && (
                      <div className="bg-purple-50 p-4 rounded-xl border border-purple-200">
                        <p className="text-sm text-purple-800">
                          <Sparkles className="w-4 h-4 inline mr-2" />
                          <strong>Occasion Context:</strong> Analysis based on: "{occasion}"
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-4">
                    <button
                      onClick={resetAnalysis}
                      className="flex-1 py-4 bg-purple-600 text-white rounded-xl hover:bg-purple-700 transition-colors font-bold text-lg shadow-lg"
                    >
                      🔄 Analyze Another Outfit
                    </button>
                    <button
                      onClick={() => {
                        const link = document.createElement('a');
                        link.href = capturedImage;
                        link.download = `outfit-analysis-${Date.now()}.jpg`;
                        link.click();
                      }}
                      className="px-8 py-4 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-colors font-bold shadow-lg"
                    >
                      💾 Save
                    </button>
                  </div>
                </div>
              )}
              
              {/* Empty State */}
              {!showCamera && !capturedImage && !analyzing && (
                <div className="text-center py-12 text-gray-400">
                  <Eye className="w-20 h-20 mx-auto mb-4 opacity-30" />
                  <p className="text-lg">Upload or capture a photo to get AI analysis</p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer - Tech Stack Info */}
        <div className="mt-8 text-center">
          <p className="text-sm text-gray-600 mb-3">⚡ Powered by Advanced AI Technologies:</p>
          <div className="flex flex-wrap justify-center gap-2">
            <span className="bg-white px-4 py-2 rounded-full text-xs font-medium text-gray-700 shadow-sm border border-gray-200">
              OpenAI GPT-4 Vision
            </span>
            <span className="bg-white px-4 py-2 rounded-full text-xs font-medium text-gray-700 shadow-sm border border-gray-200">
              OpenAI GPT-3.5 Turbo
            </span>
            <span className="bg-white px-4 py-2 rounded-full text-xs font-medium text-gray-700 shadow-sm border border-gray-200">
              TensorFlow.js
            </span>
            <span className="bg-white px-4 py-2 rounded-full text-xs font-medium text-gray-700 shadow-sm border border-gray-200">
              COCO-SSD
            </span>
            <span className="bg-white px-4 py-2 rounded-full text-xs font-medium text-gray-700 shadow-sm border border-gray-200">
              MobileNet
            </span>
            <span className="bg-white px-4 py-2 rounded-full text-xs font-medium text-gray-700 shadow-sm border border-gray-200">
              React 18
            </span>
            <span className="bg-white px-4 py-2 rounded-full text-xs font-medium text-gray-700 shadow-sm border border-gray-200">
              OpenWeatherMap API
            </span>
          </div>
          
          <div className="mt-6 text-xs text-gray-500">
            <p>© 2025 AI Fashion Outfit Suggester | Built with ❤️ and AI</p>
          </div>
        </div>
      </div>
      
      {/* Global Styles for Animations */}
      <style jsx>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .animate-fadeIn {
          animation: fadeIn 0.5s ease-out;
        }
      `}</style>
    </div>
  );
}

// Export the component
export default AIFashionSuggester;