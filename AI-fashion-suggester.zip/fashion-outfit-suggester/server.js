import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import axios from 'axios';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json({ limit: '50mb' }));

// OpenRouter Configuration
const OPENROUTER_API_KEY = process.env.OPENROUTER_API_KEY;
const OPENROUTER_BASE_URL = 'https://openrouter.ai/api/v1';

// Hindu Festivals Database
const hinduFestivals = [
  { name: 'Makar Sankranti', date: '2025-01-14', month: 1 },
  { name: 'Vasant Panchami', date: '2025-02-03', month: 2 },
  { name: 'Maha Shivaratri', date: '2025-02-26', month: 2 },
  { name: 'Holi', date: '2025-03-14', month: 3 },
  { name: 'Ugadi/Gudi Padwa', date: '2025-03-30', month: 3 },
  { name: 'Ram Navami', date: '2025-04-06', month: 4 },
  { name: 'Hanuman Jayanti', date: '2025-04-13', month: 4 },
  { name: 'Akshaya Tritiya', date: '2025-04-30', month: 4 },
  { name: 'Guru Purnima', date: '2025-07-10', month: 7 },
  { name: 'Nag Panchami', date: '2025-08-01', month: 8 },
  { name: 'Raksha Bandhan', date: '2025-08-09', month: 8 },
  { name: 'Krishna Janmashtami', date: '2025-08-16', month: 8 },
  { name: 'Ganesh Chaturthi', date: '2025-08-27', month: 8 },
  { name: 'Navratri', date: '2025-09-22', month: 9 },
  { name: 'Dussehra', date: '2025-10-02', month: 10 },
  { name: 'Karva Chauth', date: '2025-10-20', month: 10 },
  { name: 'Dhanteras', date: '2025-10-29', month: 10 },
  { name: 'Diwali', date: '2025-10-31', month: 10 },
  { name: 'Bhai Dooj', date: '2025-11-02', month: 11 },
  { name: 'Chhath Puja', date: '2025-11-05', month: 11 }
];

// Weather endpoint
app.get('/api/weather/:city', async (req, res) => {
  try {
    const { city } = req.params;
    const response = await axios.get(
      `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${process.env.WEATHER_API_KEY}&units=metric`
    );
    
    const currentMonth = new Date().getMonth() + 1;
    const upcomingFestivals = hinduFestivals
      .filter(f => f.month >= currentMonth)
      .slice(0, 5);

    res.json({
      weather: response.data,
      festivals: upcomingFestivals.length > 0 ? upcomingFestivals : hinduFestivals.slice(0, 5)
    });
  } catch (error) {
    console.error('Weather API Error:', error.message);
    res.status(500).json({ error: 'Weather fetch failed', message: error.message });
  }
});

// AI Outfit Suggestion endpoint (using OpenRouter)
app.post('/api/suggest-outfit', async (req, res) => {
  try {
    const { question, weather } = req.body;
    
    if (!OPENROUTER_API_KEY) {
      throw new Error('OPENROUTER_API_KEY is not configured in .env file');
    }

    const systemPrompt = `You are an expert Indian fashion stylist and wardrobe consultant. Provide detailed, practical fashion advice considering:
- Indian fashion trends and traditional wear
- Weather conditions (temperature: ${weather?.temp || 'N/A'}°C, condition: ${weather?.condition || 'N/A'})
- Occasion appropriateness
- Color coordination
- Jewelry recommendations
- Fabric suggestions
- Styling tips

Format your response with clear sections:
1. Main Recommendation
2. Outfit Options (2-3 specific suggestions)
3. Jewelry Advice
4. Color Palette (list 4-5 colors)
5. Footwear Suggestions
6. Accessories
7. Styling Tips

Be specific and practical. If user asks "saree or lehenga", give pros/cons of both. If asking about jewelry, compare options.`;

    console.log('🤖 Calling OpenRouter API...');

    const response = await axios.post(
      `${OPENROUTER_BASE_URL}/chat/completions`,
      {
        model: 'openai/gpt-3.5-turbo', // You can change this to other models
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: question }
        ],
        temperature: 0.7,
        max_tokens: 1000
      },
      {
        headers: {
          'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
          'Content-Type': 'application/json',
          'HTTP-Referer': 'http://localhost:3000', // Optional: your app URL
          'X-Title': 'AI Fashion Suggester' // Optional: your app name
        }
      }
    );

    console.log('✅ OpenRouter response received');

    res.json({ 
      suggestion: response.data.choices[0].message.content 
    });

  } catch (error) {
    console.error('OpenRouter Error:', error.response?.data || error.message);
    res.status(500).json({ 
      error: 'AI suggestion failed', 
      message: error.response?.data?.error?.message || error.message,
      details: 'Make sure OPENROUTER_API_KEY is set correctly in .env file'
    });
  }
});

// AI Outfit Analysis endpoint (using OpenRouter)
app.post('/api/analyze-outfit', async (req, res) => {
  try {
    const { imageData, detectedObjects, dominantColors, occasion, weather } = req.body;

    if (!OPENROUTER_API_KEY) {
      throw new Error('OPENROUTER_API_KEY is not configured in .env file');
    }

    const systemPrompt = `You are an expert fashion critic and stylist. Analyze the outfit based on:
- Detected clothing items: ${JSON.stringify(detectedObjects)}
- Dominant colors: ${JSON.stringify(dominantColors)}
- Occasion: ${occasion || 'general'}
- Weather: ${weather?.temp || 'N/A'}°C, ${weather?.condition || 'N/A'}

Provide a detailed analysis with:
1. Overall Score (0-100)
2. Verdict (one catchy phrase)
3. What's Working Well (2-3 specific points)
4. What Needs Improvement (2-3 specific points)
5. Specific Changes (be very specific: "Change the blue watch to a gold one", "Replace red dupatta with cream color", etc.)
6. Weather Appropriateness
7. Final Styling Tips

Be constructive, specific, and helpful. Use emojis. Give actionable advice.`;

    console.log('🔍 Analyzing outfit with OpenRouter...');

    // Try with vision model first (if available on OpenRouter)
    try {
      const visionResponse = await axios.post(
        `${OPENROUTER_BASE_URL}/chat/completions`,
        {
          model: 'openai/gpt-4-vision-preview', // Vision model
          messages: [
            {
              role: 'user',
              content: [
                { type: 'text', text: systemPrompt },
                {
                  type: 'image_url',
                  image_url: { url: imageData }
                }
              ]
            }
          ],
          max_tokens: 1500
        },
        {
          headers: {
            'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
            'Content-Type': 'application/json',
            'HTTP-Referer': 'http://localhost:3000',
            'X-Title': 'AI Fashion Suggester'
          }
        }
      );

      console.log('✅ Vision analysis complete');
      res.json({ analysis: visionResponse.data.choices[0].message.content });

    } catch (visionError) {
      console.log('⚠️ Vision model not available, using text-based analysis...');
      
      // Fallback to text-based analysis
      const textPrompt = `${systemPrompt}\n\nSince I cannot see the image, I'm analyzing based on the detected information. Please provide detailed styling feedback.`;
      
      const textResponse = await axios.post(
        `${OPENROUTER_BASE_URL}/chat/completions`,
        {
          model: 'openai/gpt-3.5-turbo',
          messages: [
            { role: 'system', content: 'You are a fashion expert providing detailed outfit analysis.' },
            { role: 'user', content: textPrompt }
          ],
          temperature: 0.7,
          max_tokens: 1000
        },
        {
          headers: {
            'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
            'Content-Type': 'application/json',
            'HTTP-Referer': 'http://localhost:3000',
            'X-Title': 'AI Fashion Suggester'
          }
        }
      );

      console.log('✅ Text-based analysis complete');
      res.json({ analysis: textResponse.data.choices[0].message.content });
    }

  } catch (error) {
    console.error('Analysis Error:', error.response?.data || error.message);
    res.status(500).json({ 
      error: 'Analysis failed', 
      message: error.response?.data?.error?.message || error.message,
      details: 'Make sure OPENROUTER_API_KEY is set correctly in .env file'
    });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    message: 'AI Fashion Server is running',
    openrouterConfigured: !!OPENROUTER_API_KEY,
    weatherConfigured: !!process.env.WEATHER_API_KEY
  });
});

app.listen(PORT, () => {
  console.log(`\n🚀 AI Fashion Server running on http://localhost:${PORT}`);
  console.log(`📝 Configuration Status:`);
  console.log(`   - OpenRouter API: ${OPENROUTER_API_KEY ? '✅ Configured' : '❌ Missing'}`);
  console.log(`   - Weather API: ${process.env.WEATHER_API_KEY ? '✅ Configured' : '❌ Missing'}`);
  console.log(`\n💡 Endpoints:`);
  console.log(`   - GET  /api/health`);
  console.log(`   - GET  /api/weather/:city`);
  console.log(`   - POST /api/suggest-outfit`);
  console.log(`   - POST /api/analyze-outfit`);
  console.log(`\n`);
});