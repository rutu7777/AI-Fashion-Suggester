import * as tf from '@tensorflow/tfjs';
import * as cocoSsd from '@tensorflow-models/coco-ssd';
import * as mobilenet from '@tensorflow-models/mobilenet';

let objectDetectionModel = null;
let classificationModel = null;

// Load models
export const loadModels = async () => {
  console.log('🔄 Loading AI models...');
  try {
    objectDetectionModel = await cocoSsd.load();
    classificationModel = await mobilenet.load();
    console.log('✅ AI models loaded successfully!');
    return true;
  } catch (error) {
    console.error('❌ Error loading models:', error);
    return false;
  }
};

// Detect objects in image (clothes, accessories, person)
export const detectObjects = async (imageElement) => {
  if (!objectDetectionModel) {
    await loadModels();
  }
  
  try {
    const predictions = await objectDetectionModel.detect(imageElement);
    
    // Filter fashion-related objects
    const fashionItems = predictions.filter(pred => 
      ['person', 'tie', 'handbag', 'suitcase', 'backpack', 'umbrella', 
       'hat', 'bottle', 'cup', 'chair', 'couch'].includes(pred.class)
    );
    
    return fashionItems.map(item => ({
      item: item.class,
      confidence: (item.score * 100).toFixed(1) + '%',
      box: item.bbox
    }));
  } catch (error) {
    console.error('Object detection error:', error);
    return [];
  }
};

// Classify image for style
export const classifyImage = async (imageElement) => {
  if (!classificationModel) {
    await loadModels();
  }
  
  try {
    const predictions = await classificationModel.classify(imageElement);
    return predictions.slice(0, 3);
  } catch (error) {
    console.error('Classification error:', error);
    return [];
  }
};

// Extract dominant colors from image
export const extractDominantColors = async (imageElement) => {
  try {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    canvas.width = imageElement.width || imageElement.videoWidth;
    canvas.height = imageElement.height || imageElement.videoHeight;
    
    ctx.drawImage(imageElement, 0, 0, canvas.width, canvas.height);
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const pixels = imageData.data;
    
    // Color quantization - simplified k-means
    const colorCounts = {};
    
    for (let i = 0; i < pixels.length; i += 4) {
      const r = Math.floor(pixels[i] / 50) * 50;
      const g = Math.floor(pixels[i + 1] / 50) * 50;
      const b = Math.floor(pixels[i + 2] / 50) * 50;
      const color = `rgb(${r},${g},${b})`;
      
      colorCounts[color] = (colorCounts[color] || 0) + 1;
    }
    
    // Get top 5 colors
    const sortedColors = Object.entries(colorCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([color]) => color);
    
    return sortedColors.map(rgbToColorName);
  } catch (error) {
    console.error('Color extraction error:', error);
    return ['Unknown'];
  }
};

// Convert RGB to color name (simplified)
const rgbToColorName = (rgb) => {
  const match = rgb.match(/\d+/g);
  if (!match) return 'Unknown';
  
  const [r, g, b] = match.map(Number);
  
  // Simple color naming logic
  if (r > 200 && g > 200 && b > 200) return 'White';
  if (r < 50 && g < 50 && b < 50) return 'Black';
  if (r > 150 && g < 100 && b < 100) return 'Red';
  if (r < 100 && g > 150 && b < 100) return 'Green';
  if (r < 100 && g < 100 && b > 150) return 'Blue';
  if (r > 150 && g > 150 && b < 100) return 'Yellow';
  if (r > 150 && g < 100 && b > 150) return 'Purple';
  if (r > 150 && g > 100 && b < 100) return 'Orange';
  if (r < 150 && g > 100 && b > 100) return 'Cyan';
  if (r > 100 && g < 100 && b < 100) return 'Brown';
  
  return 'Multi-color';
};

// Comprehensive image analysis
export const analyzeOutfitImage = async (imageElement) => {
  console.log('🔍 Analyzing outfit image...');
  
  const [objects, classification, colors] = await Promise.all([
    detectObjects(imageElement),
    classifyImage(imageElement),
    extractDominantColors(imageElement)
  ]);
  
  return {
    detectedObjects: objects,
    imageClassification: classification,
    dominantColors: colors,
    timestamp: new Date().toISOString()
  };
};