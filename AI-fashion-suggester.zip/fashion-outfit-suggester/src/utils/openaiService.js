import axios from 'axios';

const API_BASE_URL = 'http://localhost:3001/api';

export const getAIOutfitSuggestion = async (question, weather) => {
  try {
    const response = await axios.post(`${API_BASE_URL}/suggest-outfit`, {
      question,
      weather
    });
    return response.data.suggestion;
  } catch (error) {
    console.error('AI Suggestion Error:', error);
    throw new Error('Failed to get AI suggestion. Please try again.');
  }
};

export const getAIOutfitAnalysis = async (imageData, analysisData, occasion, weather) => {
  try {
    const response = await axios.post(`${API_BASE_URL}/analyze-outfit`, {
      imageData,
      detectedObjects: analysisData.detectedObjects,
      dominantColors: analysisData.dominantColors,
      occasion,
      weather
    });
    return response.data.analysis;
  } catch (error) {
    console.error('AI Analysis Error:', error);
    throw new Error('Failed to analyze outfit. Please try again.');
  }
};